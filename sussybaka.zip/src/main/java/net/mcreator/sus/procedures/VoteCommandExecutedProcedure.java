package net.mcreator.sus.procedures;

import net.minecraft.util.DamageSource;
import net.minecraft.entity.Entity;

import net.mcreator.sus.SusModElements;
import net.mcreator.sus.SusMod;

import java.util.Map;

@SusModElements.ModElement.Tag
public class VoteCommandExecutedProcedure extends SusModElements.ModElement {
	public VoteCommandExecutedProcedure(SusModElements instance) {
		super(instance, 12);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				SusMod.LOGGER.warn("Failed to load dependency entity for procedure VoteCommandExecuted!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		entity.attackEntityFrom(DamageSource.LIGHTNING_BOLT, (float) 1000000);
	}
}
